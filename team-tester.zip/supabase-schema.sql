-- Dexle run history and community statistics
-- Run this entire file once in Supabase: SQL Editor -> New query -> Run.

create extension if not exists pgcrypto;

create table if not exists public.runs (
  id uuid primary key default gen_random_uuid(),
  client_run_id uuid not null unique,
  user_id uuid not null references auth.users(id) on delete cascade,
  mode text not null check (mode in ('region', 'gauntlet')),
  region smallint check (
    (mode = 'region' and region between 1 and 9)
    or (mode = 'gauntlet' and region is null)
  ),
  wins smallint not null check (wins >= 0),
  losses smallint not null check (losses >= 0),
  total smallint not null check (total > 0 and wins + losses = total),
  tier text not null check (tier in ('poke', 'great', 'ultra', 'master', 'oak')),
  team jsonb not null check (jsonb_typeof(team) = 'array' and jsonb_array_length(team) = 6),
  team_bst integer check (team_bst > 0),
  coverage smallint check (coverage between 0 and 18),
  region_records jsonb,
  created_at timestamptz not null default now()
);

create index if not exists runs_user_created_idx
  on public.runs (user_id, created_at desc);
create index if not exists runs_mode_region_idx
  on public.runs (mode, region, created_at desc);

alter table public.runs add column if not exists team_bst integer check (team_bst > 0);
alter table public.runs add column if not exists coverage smallint check (coverage between 0 and 18);
alter table public.runs drop constraint if exists runs_mode_check;
alter table public.runs add constraint runs_mode_check check (mode in ('region','gauntlet','unlimited_region','unlimited_gauntlet','base_max','team_rocket_gauntlet'));
alter table public.runs drop constraint if exists runs_region_check;
alter table public.runs add constraint runs_region_check check ((mode in ('region','unlimited_region') and region between 1 and 9) or (mode in ('gauntlet','unlimited_gauntlet','base_max','team_rocket_gauntlet') and region is null));

create table if not exists public.dexle_games (
  id uuid primary key default gen_random_uuid(),
  client_game_id uuid not null unique,
  user_id uuid not null references auth.users(id) on delete cascade,
  won boolean not null,
  guesses_used smallint not null check (guesses_used between 0 and 10),
  hints_used smallint not null default 0 check (hints_used between 0 and 10),
  target_id integer not null check (target_id between 1 and 1025),
  generations smallint[] not null,
  created_at timestamptz not null default now(),
  check (not won or guesses_used >= 1)
);

create index if not exists dexle_games_user_created_idx
  on public.dexle_games (user_id, created_at desc);

alter table public.dexle_games enable row level security;

drop policy if exists "Players can read their own Dexle games" on public.dexle_games;
create policy "Players can read their own Dexle games"
  on public.dexle_games for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Players can save their own Dexle games" on public.dexle_games;
create policy "Players can save their own Dexle games"
  on public.dexle_games for insert to authenticated
  with check ((select auth.uid()) = user_id);

alter table public.runs enable row level security;

drop policy if exists "Players can read their own runs" on public.runs;
create policy "Players can read their own runs"
  on public.runs for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Players can save their own runs" on public.runs;
create policy "Players can save their own runs"
  on public.runs for insert to authenticated
  with check ((select auth.uid()) = user_id);

-- Community totals only. This function deliberately returns no user IDs,
-- timestamps, records, or complete team combinations.
drop function if exists public.community_top_pokemon(text, smallint, integer);
drop function if exists public.community_top_pokemon(text, smallint, smallint, integer);
drop function if exists public.community_top_pokemon(text, smallint, smallint, boolean, integer);

create or replace function public.community_top_pokemon(
  p_mode text default null,
  p_region smallint default null,
  p_generation smallint default null,
  p_starters boolean default false,
  p_limit integer default 10
)
returns table (
  pokemon_id integer,
  base_id integer,
  pokemon_name text,
  is_mega boolean,
  uses bigint
)
language sql
stable
security definer
set search_path = ''
as $$
  select
    (member->>'id')::integer as pokemon_id,
    coalesce((member->>'base_id')::integer, (member->>'id')::integer) as base_id,
    member->>'name' as pokemon_name,
    coalesce((member->>'mega')::boolean, false) as is_mega,
    count(*) as uses
  from public.runs r
  cross join lateral jsonb_array_elements(r.team) member
  where (p_mode is null or r.mode = p_mode)
    and (p_region is null or r.region = p_region)
    and (
      coalesce((member->>'base_id')::integer, (member->>'id')::integer) = any(array[
        1,2,3,4,5,6,7,8,9,
        152,153,154,155,156,157,158,159,160,
        252,253,254,255,256,257,258,259,260,
        387,388,389,390,391,392,393,394,395,
        495,496,497,498,499,500,501,502,503,
        650,651,652,653,654,655,656,657,658,
        722,723,724,725,726,727,728,729,730,
        810,811,812,813,814,815,816,817,818,
        906,907,908,909,910,911,912,913,914
      ]::integer[])
    ) = p_starters
    and (
      p_generation is null
      or p_generation = coalesce(
        (member->>'gen')::smallint,
        case
          when coalesce((member->>'base_id')::integer, (member->>'id')::integer) <= 151 then 1
          when coalesce((member->>'base_id')::integer, (member->>'id')::integer) <= 251 then 2
          when coalesce((member->>'base_id')::integer, (member->>'id')::integer) <= 386 then 3
          when coalesce((member->>'base_id')::integer, (member->>'id')::integer) <= 493 then 4
          when coalesce((member->>'base_id')::integer, (member->>'id')::integer) <= 649 then 5
          when coalesce((member->>'base_id')::integer, (member->>'id')::integer) <= 721 then 6
          when coalesce((member->>'base_id')::integer, (member->>'id')::integer) <= 809 then 7
          when coalesce((member->>'base_id')::integer, (member->>'id')::integer) <= 905 then 8
          else 9
        end
      )
    )
  group by 1, 2, 3, 4
  order by uses desc, pokemon_name asc
  limit least(greatest(p_limit, 1), 100);
$$;

create or replace function public.community_summary()
returns table (runs bigint, trainers bigint, perfect_runs bigint)
language sql
stable
security definer
set search_path = ''
as $$
  select
    count(*)::bigint,
    count(distinct user_id)::bigint,
    count(*) filter (where wins = total)::bigint
  from public.runs;
$$;

-- Public trainer names used by community records and account pages.
create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  created_at timestamptz not null default now(),
  constraint username_length check (char_length(username) between 3 and 20),
  constraint username_format check (username ~ '^[A-Za-z0-9_]+$')
);
create unique index if not exists profiles_username_lower_idx
  on public.profiles (lower(username));
alter table public.profiles add column if not exists avatar jsonb;
alter table public.profiles add column if not exists login_email text;

drop function if exists public.community_best_team();
drop function if exists public.community_best_team(text, smallint);

create or replace function public.community_best_team(
  p_mode text,
  p_region smallint default null
)
returns table (
  mode text,
  region smallint,
  wins smallint,
  losses smallint,
  total smallint,
  tier text,
  team jsonb,
  team_bst integer,
  coverage smallint,
  username text,
  created_at timestamptz
)
language sql
stable
security definer
set search_path = ''
as $$
  select
    r.mode, r.region, r.wins, r.losses, r.total, r.tier,
    r.team, r.team_bst, r.coverage,
    coalesce(p.username, 'Trainer') as username, r.created_at
  from public.runs r
  left join public.profiles p on p.user_id = r.user_id
  where r.team_bst is not null and r.wins = r.total
    and r.mode = p_mode
    and (p_region is null or r.region = p_region)
  order by r.team_bst desc, (r.wins::numeric / r.total) desc, r.created_at asc
  limit 1;
$$;

create or replace function public.personal_dexle_summary()
returns table (
  total_games bigint,
  wins bigint,
  fails bigint,
  win_rate numeric,
  average_guesses numeric,
  current_streak bigint,
  best_streak bigint,
  guess_distribution jsonb
)
language sql
stable
security invoker
set search_path = ''
as $$
  with mine as (
    select *
    from public.dexle_games
    where user_id = auth.uid()
  ),
  newest as (
    select won, row_number() over (order by created_at desc, id desc) as rn
    from mine
  ),
  first_loss as (
    select min(rn) as rn from newest where not won
  ),
  grouped as (
    select won,
      sum(case when not won then 1 else 0 end)
        over (order by created_at, id) as loss_group
    from mine
  ),
  streaks as (
    select loss_group, count(*) as length
    from grouped where won group by loss_group
  )
  select
    count(*)::bigint,
    count(*) filter (where m.won)::bigint,
    count(*) filter (where not m.won)::bigint,
    coalesce(round(100.0 * count(*) filter (where m.won) / nullif(count(*), 0), 1), 0),
    coalesce(round(avg(m.guesses_used) filter (where m.won), 2), 0),
    coalesce((select count(*) from newest n
      where n.won and n.rn < coalesce((select rn from first_loss), 9223372036854775807)), 0)::bigint,
    coalesce((select max(length) from streaks), 0)::bigint,
    jsonb_build_object(
      '1', count(*) filter (where m.won and m.guesses_used = 1),
      '2', count(*) filter (where m.won and m.guesses_used = 2),
      '3', count(*) filter (where m.won and m.guesses_used = 3),
      '4', count(*) filter (where m.won and m.guesses_used = 4),
      '5', count(*) filter (where m.won and m.guesses_used = 5),
      '6', count(*) filter (where m.won and m.guesses_used = 6),
      '7', count(*) filter (where m.won and m.guesses_used = 7),
      '8', count(*) filter (where m.won and m.guesses_used = 8),
      '9', count(*) filter (where m.won and m.guesses_used = 9),
      '10', count(*) filter (where m.won and m.guesses_used = 10)
    )
  from mine m;
$$;

revoke all on table public.runs from anon;
grant select, insert on table public.runs to authenticated;
revoke all on table public.dexle_games from anon;
grant select, insert on table public.dexle_games to authenticated;

revoke execute on function public.community_top_pokemon(text, smallint, smallint, boolean, integer) from public, anon;
grant execute on function public.community_top_pokemon(text, smallint, smallint, boolean, integer) to authenticated;
revoke execute on function public.community_summary() from public, anon;
grant execute on function public.community_summary() to authenticated;
revoke execute on function public.community_best_team(text, smallint) from public, anon;
grant execute on function public.community_best_team(text, smallint) to authenticated;
revoke execute on function public.personal_dexle_summary() from public, anon;
grant execute on function public.personal_dexle_summary() to authenticated;

-- =========================================================
-- Accounts, Hall of Fame, and Shiny Dex
-- Run this whole file again after adding these features.
-- =========================================================

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null,
  created_at timestamptz not null default now(),
  constraint username_length check (char_length(username) between 3 and 20),
  constraint username_format check (username ~ '^[A-Za-z0-9_]+$')
);
create unique index if not exists profiles_username_lower_idx
  on public.profiles (lower(username));

alter table public.profiles enable row level security;
drop policy if exists "Profiles are publicly readable" on public.profiles;
create policy "Profiles are publicly readable" on public.profiles
  for select to authenticated using (true);
drop policy if exists "Players can create their profile" on public.profiles;
create policy "Players can create their profile" on public.profiles
  for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "Players can update their profile" on public.profiles;
create policy "Players can update their profile" on public.profiles
  for update to authenticated using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

create table if not exists public.shiny_dex (
  user_id uuid not null references auth.users(id) on delete cascade,
  form_key text not null,
  pokemon_id integer not null,
  base_id integer not null check (base_id between 1 and 1025),
  pokemon_name text not null,
  is_mega boolean not null default false,
  first_seen_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  times_seen integer not null default 1 check (times_seen > 0),
  primary key (user_id, form_key)
);
create index if not exists shiny_dex_user_recent_idx
  on public.shiny_dex (user_id, last_seen_at desc);

alter table public.shiny_dex enable row level security;
drop policy if exists "Players can read their Shiny Dex" on public.shiny_dex;
create policy "Players can read their Shiny Dex" on public.shiny_dex
  for select to authenticated using ((select auth.uid()) = user_id);

create or replace function public.collect_run_shinies()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare member jsonb;
declare v_id integer;
declare v_base integer;
declare v_mega boolean;
declare v_key text;
begin
  for member in select value from jsonb_array_elements(new.team)
  loop
    if coalesce((member->>'shiny')::boolean, false) then
      v_id := (member->>'id')::integer;
      v_base := coalesce((member->>'base_id')::integer, v_id);
      v_mega := coalesce((member->>'mega')::boolean, false);
      v_key := case
        when v_mega then 'mega:' || v_id || ':' || regexp_replace(lower(member->>'name'), '[^a-z0-9]+', '-', 'g')
        when coalesce((member->>'type_form')::boolean, false) or v_id <> v_base then 'form:' || v_id || ':' || regexp_replace(lower(member->>'name'), '[^a-z0-9]+', '-', 'g')
        else 'base:' || v_base
      end;
      insert into public.shiny_dex
        (user_id, form_key, pokemon_id, base_id, pokemon_name, is_mega,
         first_seen_at, last_seen_at, times_seen)
      values
        (new.user_id, v_key, v_id, v_base, member->>'name', v_mega,
         new.created_at, new.created_at, 1)
      on conflict (user_id, form_key) do update set
        last_seen_at = greatest(public.shiny_dex.last_seen_at, excluded.last_seen_at),
        times_seen = public.shiny_dex.times_seen + 1,
        pokemon_name = excluded.pokemon_name;

    end if;
  end loop;
  return new;
end;
$$;

drop trigger if exists runs_collect_shinies on public.runs;
create trigger runs_collect_shinies
after insert on public.runs
for each row execute function public.collect_run_shinies();

-- Unlimited runs use this same trigger, so shiny team members from
-- unlimited_region, unlimited_gauntlet, and base_max are collected too.

-- Backfill shinies already saved in existing completed runs.
insert into public.shiny_dex
  (user_id, form_key, pokemon_id, base_id, pokemon_name, is_mega,
   first_seen_at, last_seen_at, times_seen)
select r.user_id,
  case
    when coalesce((m->>'mega')::boolean, false) then 'mega:' || (m->>'id') || ':' || regexp_replace(lower(m->>'name'), '[^a-z0-9]+', '-', 'g')
    when coalesce((m->>'type_form')::boolean, false) or (m->>'id')::integer <> coalesce((m->>'base_id')::integer, (m->>'id')::integer)
      then 'form:' || (m->>'id') || ':' || regexp_replace(lower(m->>'name'), '[^a-z0-9]+', '-', 'g')
    else 'base:' || coalesce(m->>'base_id', m->>'id')
  end,
  (m->>'id')::integer,
  coalesce((m->>'base_id')::integer, (m->>'id')::integer),
  m->>'name', coalesce((m->>'mega')::boolean, false),
  min(r.created_at), max(r.created_at), count(*)::integer
from public.runs r cross join lateral jsonb_array_elements(r.team) m
where coalesce((m->>'shiny')::boolean, false)
group by 1,2,3,4,5,6
on conflict (user_id, form_key) do nothing;

-- Remove any placeholder evolution-line entries made by the short-lived
-- three-stage starter experiment. Genuine catches have their real names.
delete from public.shiny_dex where pokemon_name like 'Starter #%';

create or replace function public.community_hall_of_fame(
  p_mode text,
  p_region smallint default null,
  p_limit integer default 100
)
returns table (
  id uuid, mode text, region smallint, wins smallint, losses smallint,
  total smallint, team jsonb, team_bst integer, coverage smallint,
  username text, created_at timestamptz
)
language sql stable security definer set search_path = ''
as $$
  select r.id, r.mode, r.region, r.wins, r.losses, r.total, r.team,
    r.team_bst, r.coverage, coalesce(p.username, 'Trainer'), r.created_at
  from public.runs r
  left join public.profiles p on p.user_id = r.user_id
  where r.user_id = auth.uid()
    and r.wins = r.total and r.mode = p_mode
    and (p_region is null or r.region = p_region)
  order by r.created_at desc
  limit least(greatest(p_limit, 1), 250);
$$;

revoke all on table public.profiles from anon;
grant select, insert, update on table public.profiles to authenticated;
revoke all on table public.shiny_dex from anon;
grant select on table public.shiny_dex to authenticated;
revoke execute on function public.community_hall_of_fame(text, smallint, integer) from public, anon;
grant execute on function public.community_hall_of_fame(text, smallint, integer) to authenticated;

-- =========================================================
-- Trainer friends and private friend profiles
-- =========================================================
create table if not exists public.friend_requests (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references auth.users(id) on delete cascade,
  addressee_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (requester_id <> addressee_id)
);
create unique index if not exists friend_pair_unique_idx on public.friend_requests
  (least(requester_id,addressee_id), greatest(requester_id,addressee_id));
alter table public.friend_requests enable row level security;
drop policy if exists "Friends can see their connections" on public.friend_requests;
create policy "Friends can see their connections" on public.friend_requests for select to authenticated
  using ((select auth.uid()) in (requester_id,addressee_id));
drop policy if exists "Players can send friend requests" on public.friend_requests;
create policy "Players can send friend requests" on public.friend_requests for insert to authenticated
  with check ((select auth.uid())=requester_id and status='pending');
drop policy if exists "Players can answer friend requests" on public.friend_requests;
drop policy if exists "Players can remove friend connections" on public.friend_requests;
create policy "Players can remove friend connections" on public.friend_requests for delete to authenticated
  using ((select auth.uid()) in (requester_id,addressee_id));

create or replace function public.friend_profile(p_user_id uuid)
returns jsonb language plpgsql stable security definer set search_path=''
as $$
declare result jsonb;
begin
  if p_user_id=auth.uid() or not exists (
    select 1 from public.friend_requests f where f.status='accepted'
      and ((f.requester_id=auth.uid() and f.addressee_id=p_user_id)
        or (f.addressee_id=auth.uid() and f.requester_id=p_user_id))
  ) then raise exception 'You must be friends to view this Trainer profile.'; end if;
  select jsonb_build_object(
    'user_id',p_user_id,'username',p.username,'avatar',p.avatar,
    'hall',coalesce((select jsonb_agg(to_jsonb(r) order by r.created_at desc)
      from public.runs r where r.user_id=p_user_id and r.wins=r.total),'[]'::jsonb),
    'shinies',coalesce((select jsonb_agg(to_jsonb(s) order by s.last_seen_at desc)
      from public.shiny_dex s where s.user_id=p_user_id),'[]'::jsonb)
  ) into result from public.profiles p where p.user_id=p_user_id;
  return result;
end; $$;

create or replace function public.accept_friend_request(p_request_id uuid)
returns void language plpgsql security definer set search_path=''
as $$ begin
  update public.friend_requests set status='accepted',updated_at=now()
  where id=p_request_id and addressee_id=auth.uid() and status='pending';
  if not found then raise exception 'Friend request was not found.'; end if;
end; $$;

revoke all on table public.friend_requests from anon;
revoke update on table public.friend_requests from authenticated;
grant select,insert,delete on table public.friend_requests to authenticated;
revoke execute on function public.friend_profile(uuid) from public,anon;
grant execute on function public.friend_profile(uuid) to authenticated;

create table if not exists public.daily_champion_results (
  user_id uuid not null references auth.users(id) on delete cascade,
  challenge_date date not null, champion text not null,
  attempts integer not null check (attempts > 0),
  team jsonb not null check (jsonb_typeof(team)='array' and jsonb_array_length(team)=6),
  team_bst integer not null check (team_bst > 0),
  pokemon_left smallint not null check (pokemon_left between 1 and 6),
  created_at timestamptz not null default now(), primary key (user_id,challenge_date)
);
alter table public.daily_champion_results enable row level security;
drop policy if exists "Players read their Daily Champion history" on public.daily_champion_results;
create policy "Players read their Daily Champion history" on public.daily_champion_results for select to authenticated using (auth.uid()=user_id);
drop policy if exists "Players save their Daily Champion results" on public.daily_champion_results;
create policy "Players save their Daily Champion results" on public.daily_champion_results for insert to authenticated with check (auth.uid()=user_id);
grant select,insert on public.daily_champion_results to authenticated;


-- Records shiny team members from attempts that do not create a run/result row.
-- Final form state is authoritative: a Mega/type-changed shiny unlocks only that form.
create or replace function public.record_shiny_team(p_team jsonb)
returns void
language plpgsql
security definer
set search_path=''
as $$
declare
  member jsonb;
  v_user uuid := auth.uid();
  v_id integer;
  v_base integer;
  v_mega boolean;
  v_key text;
begin
  if v_user is null then raise exception 'Authentication required.'; end if;
  if jsonb_typeof(p_team) <> 'array' then raise exception 'Team must be an array.'; end if;

  for member in select value from jsonb_array_elements(p_team)
  loop
    if coalesce((member->>'shiny')::boolean,false) then
      v_id := (member->>'id')::integer;
      v_base := coalesce((member->>'base_id')::integer,v_id);
      v_mega := coalesce((member->>'mega')::boolean,false);
      v_key := case
        when v_mega then 'mega:'||v_id||':'||regexp_replace(lower(member->>'name'),'[^a-z0-9]+','-','g')
        when coalesce((member->>'type_form')::boolean,false) or v_id<>v_base
          then 'form:'||v_id||':'||regexp_replace(lower(member->>'name'),'[^a-z0-9]+','-','g')
        else 'base:'||v_base
      end;

      insert into public.shiny_dex
        (user_id,form_key,pokemon_id,base_id,pokemon_name,is_mega,
         first_seen_at,last_seen_at,times_seen)
      values
        (v_user,v_key,v_id,v_base,member->>'name',v_mega,now(),now(),1)
      on conflict(user_id,form_key) do update set
        last_seen_at=greatest(public.shiny_dex.last_seen_at,excluded.last_seen_at),
        times_seen=public.shiny_dex.times_seen+1,
        pokemon_name=excluded.pokemon_name;
    end if;
  end loop;
end;
$$;

revoke all on function public.record_shiny_team(jsonb) from public,anon;
grant execute on function public.record_shiny_team(jsonb) to authenticated;

create or replace function public.collect_daily_champion_shinies() returns trigger language plpgsql security definer set search_path='' as $$
declare member jsonb; declare v_id integer; declare v_base integer; declare v_mega boolean; declare v_key text;
begin for member in select value from jsonb_array_elements(new.team) loop if coalesce((member->>'shiny')::boolean,false) then
v_id=(member->>'id')::integer; v_base=coalesce((member->>'base_id')::integer,v_id); v_mega=coalesce((member->>'mega')::boolean,false);
v_key=case when v_mega then 'mega:'||v_id||':'||regexp_replace(lower(member->>'name'),'[^a-z0-9]+','-','g') when coalesce((member->>'type_form')::boolean,false) or v_id<>v_base then 'form:'||v_id||':'||regexp_replace(lower(member->>'name'),'[^a-z0-9]+','-','g') else 'base:'||v_base end;
insert into public.shiny_dex(user_id,form_key,pokemon_id,base_id,pokemon_name,is_mega,first_seen_at,last_seen_at,times_seen) values(new.user_id,v_key,v_id,v_base,member->>'name',v_mega,new.created_at,new.created_at,1)
on conflict(user_id,form_key) do update set last_seen_at=greatest(public.shiny_dex.last_seen_at,excluded.last_seen_at),times_seen=public.shiny_dex.times_seen+1,pokemon_name=excluded.pokemon_name;
end if; end loop; return new; end $$;
drop trigger if exists daily_champion_collect_shinies on public.daily_champion_results;
create trigger daily_champion_collect_shinies after insert on public.daily_champion_results for each row execute function public.collect_daily_champion_shinies();

-- Upgrade older ID-only bonus-form keys. Merge first because a Trainer may
-- already own both the old key and its newer name-aware equivalent.
insert into public.shiny_dex
  (user_id,form_key,pokemon_id,base_id,pokemon_name,is_mega,
   first_seen_at,last_seen_at,times_seen)
select user_id,
  (case when is_mega then 'mega:' else 'form:' end) || pokemon_id || ':' ||
    regexp_replace(lower(pokemon_name),'[^a-z0-9]+','-','g'),
  pokemon_id,base_id,pokemon_name,is_mega,first_seen_at,last_seen_at,times_seen
from public.shiny_dex
where form_key not like 'base:%' and form_key !~ '^(mega|form):[0-9]+:'
on conflict (user_id,form_key) do update set
  first_seen_at=least(public.shiny_dex.first_seen_at,excluded.first_seen_at),
  last_seen_at=greatest(public.shiny_dex.last_seen_at,excluded.last_seen_at),
  times_seen=public.shiny_dex.times_seen+excluded.times_seen,
  pokemon_name=excluded.pokemon_name;

delete from public.shiny_dex
where form_key not like 'base:%' and form_key !~ '^(mega|form):[0-9]+:';

-- Username login support. Email remains available only through this narrow
-- resolver used immediately by Supabase password authentication.
update public.profiles p set login_email=lower(u.email)
from auth.users u where u.id=p.user_id and p.login_email is distinct from lower(u.email);

create or replace function public.email_for_username(p_username text)
returns text language sql stable security definer set search_path='' as $$
  select p.login_email from public.profiles p
  where lower(p.username)=lower(trim(p_username)) limit 1;
$$;
revoke execute on function public.email_for_username(text) from public,anon;
grant execute on function public.email_for_username(text) to authenticated;

-- Prevent normal profile reads from exposing login emails.
revoke select on public.profiles from authenticated;
grant select (user_id,username,avatar,created_at) on public.profiles to authenticated;
revoke execute on function public.accept_friend_request(uuid) from public,anon;
grant execute on function public.accept_friend_request(uuid) to authenticated;
