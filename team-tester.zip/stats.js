(function () {
  "use strict";

  const REGIONS = {1:"Kanto",2:"Johto",3:"Hoenn",4:"Sinnoh",5:"Unova",
    6:"Kalos",7:"Alola",8:"Galar",9:"Paldea"};
  const TIER = {
    poke:"#E0483C", great:"#3E7BD6", ultra:"#F0C020",
    master:"#B061D6", oak:"#5FE3B0",
  };
  const $ = id => document.getElementById(id);
  const UNLIMITED_VIEW=new URLSearchParams(location.search).get("view")==="unlimited";
  const sprite = (id, shiny) =>
    `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${shiny ? "shiny/" : ""}${id}.png`;
  const CANDY_ICON =
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/items/rare-candy.png";
  const STARTER_SPECIES = new Set([
    [1,9],[152,160],[252,260],[387,395],[495,503],
    [650,658],[722,730],[810,818],[906,914],
  ].flatMap(([first,last]) => Array.from({length:last-first+1},(_,i) => first+i)));
  const localSprite = (id, shiny) =>
    id === 10301 ? "assets/megas/mega-zygarde.png" : sprite(id, shiny);
  const savedSprite = mon => {
    const custom = mon.shiny ? mon.shiny_sprite : mon.sprite;
    return custom
      ? `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${custom}`
      : localSprite(mon.id, mon.shiny);
  };
  let runs = [];
  let scope = "personal";
  let historyMode = UNLIMITED_VIEW ? "unlimited_region" : "region";
  let showStarters = false;

  function pokemonGeneration(mon) {
    if (mon.gen) return +mon.gen;
    const id = +(mon.base_id || mon.id);
    return id <= 151 ? 1 : id <= 251 ? 2 : id <= 386 ? 3 :
      id <= 493 ? 4 : id <= 649 ? 5 : id <= 721 ? 6 :
      id <= 809 ? 7 : id <= 905 ? 8 : 9;
  }

  function regionOptions(allLabel) {
    return `<option value="">${allLabel}</option>` +
      Object.entries(REGIONS).map(([id,name]) => `<option value="${id}">${name}</option>`).join("");
  }

  function monImg(mon) {
    return `<img src="${savedSprite(mon)}" alt="${mon.name}" loading="lazy"
      onerror="this.onerror=null;this.src='${sprite(mon.base_id || mon.id, mon.shiny)}'">`;
  }

  function teamHtml(team) {
    return `<div class="team">${team.map(m => `
      <span class="mon ${m.mega ? "mega" : ""} ${m.type_form ? "type-form" : ""} ${m.shiny ? "shiny" : ""} ${m.shadow ? "shadow" : ""} ${m.candy ? "candy" : ""}"
        title="${m.name}${m.mega ? " · Mega" : ""}${m.shiny ? " · Shiny" : ""}${m.shadow ? " · Shadow Pokémon +50%" : ""}${m.candy ? " · Rare Candy" : ""}">
        ${monImg(m)}
        ${m.candy ? `<span class="candy-mark"><img src="${CANDY_ICON}" alt="Rare Candy"></span>` : ""}
        ${m.mega ? `<span class="mega-mark" aria-label="Mega Evolved">◈</span>` : ""}
        ${m.type_form ? `<span class="type-form-mark" aria-label="Changed Type">◇</span>` : ""}
        ${m.shiny ? `<span class="shiny-mark" aria-label="Shiny">✦</span>` : ""}
      </span>`).join("")}</div>`;
  }

  function runCard(run) {
    const title = run.mode === "unlimited_region" ? `Region Ascendant · ${REGIONS[run.region]||"Region"}` : run.mode === "unlimited_gauntlet" ? "Infinite Gauntlet" : run.mode === "base_max" ? "Base Form Fury" : run.mode === "team_rocket_gauntlet" ? "Shadow Challenge" : run.mode === "gauntlet" ? "Gauntlet" : REGIONS[run.region];
    const date = new Date(run.created_at).toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"});
    return `<article class="run-card ${run.wins === run.total ? "flawless" : ""}">
      <div class="run-top">
        <span class="rankball ${run.tier === "oak" ? "oak-disc" : ""}" style="--tier:${TIER[run.tier]}"></span>
        <div class="run-title"><b>${title}</b><small>${date}</small></div>
        <div class="team-metrics"><span>Stats <b>${Number(run.team_bst||0).toLocaleString()}</b></span><span>Coverage <b>${run.coverage??0}/18</b></span></div>
        <span class="record"><span class="wins">${run.wins}</span><i>&ndash;</i><span class="losses">${run.losses}</span></span>
      </div>
      ${teamHtml(run.team)}
    </article>`;
  }

  function best(list) {
    return [...list.filter(r=>r.wins===r.total)].sort((a,b) =>
      (+b.team_bst||0)-(+a.team_bst||0) ||
      new Date(b.created_at) - new Date(a.created_at)
    )[0] || null;
  }

  function personalTop(mode, generation) {
    const filtered = runs.filter(r => !mode || r.mode === mode);
    const counts = new Map();
    filtered.forEach(r => r.team
      .filter(m => STARTER_SPECIES.has(+(m.base_id || m.id)) === showStarters)
      .filter(m => !generation || pokemonGeneration(m) === +generation)
      .forEach(m => {
      const key = `${m.id}|${!!m.mega}`;
      const item = counts.get(key) || {
        pokemon_id:m.id, pokemon_name:m.name, is_mega:!!m.mega,
        base_id:m.base_id, uses:0,
      };
      item.uses++;
      counts.set(key,item);
    }));
    return [...counts.values()].sort((a,b) => b.uses-a.uses || a.pokemon_name.localeCompare(b.pokemon_name)).slice(0,10);
  }

  function drawLeaders(list) {
    $("leaderboard").innerHTML = list.length ? list.map((m,i) => `
      <div class="leader">
        <span class="place">${i+1}</span>
        <img src="${localSprite(m.pokemon_id)}" alt="" onerror="this.onerror=null;this.src='${sprite(m.base_id || m.pokemon_id)}'">
        <div><b>${m.pokemon_name}</b>${m.is_mega ? '<span class="mega-tag">MEGA</span>' : ""}
          <small>${scope === "community" ? "Community teams" : "Your teams"}</small></div>
        <span class="uses">${m.uses} use${+m.uses === 1 ? "" : "s"}</span>
      </div>`).join("") : '<p class="empty">No completed runs match these filters yet.</p>';
  }

  async function refreshLeaderboard() {
    const mode = $("usageMode").value;
    const generation = $("usageGeneration").value;
    $("leaderboard").innerHTML = '<p class="empty">Loading rankings…</p>';
    if (scope === "personal") {
      return drawLeaders(personalTop(mode, generation));
    }
    try {
      if(UNLIMITED_VIEW&&!mode){
        const lists=await Promise.all(["unlimited_region","unlimited_gauntlet","base_max"].map(m=>DexleStats.communityTop(m,+generation||null,showStarters,50)));
        const merged=new Map();lists.flat().forEach(p=>{const key=`${p.pokemon_id}|${!!p.is_mega}`,old=merged.get(key);if(old)old.uses=+old.uses + +p.uses;else merged.set(key,{...p,uses:+p.uses});});
        return drawLeaders([...merged.values()].sort((a,b)=>b.uses-a.uses).slice(0,10));
      }
      drawLeaders(await DexleStats.communityTop(
        mode, +generation || null, showStarters, 10
      ));
    } catch (err) { showError(err); }
  }

  function drawHistory() {
    const region = $("historyRegion").value;
    $("historyFilters").hidden = historyMode !== "region";
    const list = runs.filter(r => r.mode === historyMode &&
      (historyMode !== "region" || !region || r.region === +region)).slice(0,5);
    $("history").innerHTML = list.length ? list.map(runCard).join("") :
      '<p class="empty">Your completed teams will appear here.</p>';
  }

  function drawBests() {
    if(UNLIMITED_VIEW){
      const regionBest=best(runs.filter(r=>r.mode==="unlimited_region"));
      const gauntletBest=best(runs.filter(r=>r.mode==="unlimited_gauntlet"));
      const furyBest=best(runs.filter(r=>r.mode==="base_max"));
      $("bestRegionCard").innerHTML=regionBest?runCard(regionBest):'<p class="empty">No flawless Region Ascendant runs yet.</p>';
      $("bestGauntletCard").innerHTML=gauntletBest?runCard(gauntletBest):'<p class="empty">No flawless Infinite Gauntlet runs yet.</p>';
      $("bestRocketCard").innerHTML=furyBest?runCard(furyBest):'<p class="empty">No flawless Base Form Fury runs yet.</p>';
      return;
    }
    const region = $("bestRegion").value;
    const regionBest = best(runs.filter(r => r.mode === "region" && (!region || r.region === +region)));
    const gauntletBest = best(runs.filter(r => r.mode === "gauntlet"));
    const rocketBest = best(runs.filter(r => r.mode === "team_rocket_gauntlet"));
    $("bestRegionCard").innerHTML = regionBest ? runCard(regionBest) : '<p class="empty">No Region runs yet.</p>';
    $("bestGauntletCard").innerHTML = gauntletBest ? runCard(gauntletBest) : '<p class="empty">No Gauntlet runs yet.</p>';
    $("bestRocketCard").innerHTML = rocketBest ? runCard(rocketBest) : '<p class="empty">No flawless Team Rocket runs yet.</p>';
  }

  function communityBestCard(run) {
    if (!run) {
      return '<p class="empty">The first qualifying team will claim this spot.</p>';
    }
    const title = run.mode === "unlimited_region" ? `Region Ascendant · ${REGIONS[run.region]||"Region"}` : run.mode === "unlimited_gauntlet" ? "Infinite Gauntlet" : run.mode === "base_max" ? "Base Form Fury" : run.mode === "team_rocket_gauntlet" ? "Shadow Challenge" : run.mode === "gauntlet"
      ? "Gauntlet"
      : REGIONS[run.region];
    return `
      <article class="run-card community-best-card ${run.wins === run.total ? "flawless" : ""}">
        <div class="run-top">
          <span class="rankball ${run.tier === "oak" ? "oak-disc" : ""}" style="--tier:${TIER[run.tier]}"></span>
          <div class="run-title"><b>${title}</b>${run.username ? `<small>@${run.username}</small>` : ""}</div>
          <div class="team-metrics"><span>Stats <b>${run.team_bst.toLocaleString()}</b></span><span>Coverage <b>${run.coverage}/18</b></span></div>
          <span class="record"><span class="wins">${run.wins}</span><i>&ndash;</i><span class="losses">${run.losses}</span></span>
        </div>
        ${teamHtml(run.team)}
      </article>`;
  }

  async function refreshCommunityBests() {
    const region = +$("communityBestRegion").value || null;
    try {
      if(UNLIMITED_VIEW){
        const [regionBest,gauntletBest,furyBest]=await Promise.all([DexleStats.communityBestTeam("unlimited_region",null),DexleStats.communityBestTeam("unlimited_gauntlet",null),DexleStats.communityBestTeam("base_max",null)]);
        $("communityBestRegionCard").innerHTML=communityBestCard(regionBest);$("communityBestGauntletCard").innerHTML=communityBestCard(gauntletBest);$("communityBestRocketCard").innerHTML=communityBestCard(furyBest);return;
      }
      const [regionBest, gauntletBest, rocketBest] = await Promise.all([
        DexleStats.communityBestTeam("region", region),
        DexleStats.communityBestTeam("gauntlet", null),
        DexleStats.communityBestTeam("team_rocket_gauntlet", null),
      ]);
      $("communityBestRegionCard").innerHTML = communityBestCard(regionBest);
      $("communityBestGauntletCard").innerHTML = communityBestCard(gauntletBest);
      $("communityBestRocketCard").innerHTML = communityBestCard(rocketBest);
    } catch (err) { showError(err); }
  }

  function drawSummary(community) {
    const perfect = runs.filter(r => r.wins === r.total).length;
    const regionCounts = {};
    runs.filter(r => r.mode === "region").forEach(r => regionCounts[r.region] = (regionCounts[r.region] || 0) + 1);
    const favorite = Object.keys(regionCounts).sort((a,b) => regionCounts[b]-regionCounts[a])[0];
    const values = [runs.length, perfect, favorite ? REGIONS[favorite] : "—", Number(community.runs || 0).toLocaleString()];
    [...$("summary").children].forEach((el,i) => el.querySelector("b").textContent = values[i]);
  }

  function drawDexleProgress(stats) {
    const s = stats || {
      total_games:0, wins:0, fails:0, win_rate:0, average_guesses:0,
      current_streak:0, best_streak:0, guess_distribution:{},
    };
    const values = [
      s.total_games, s.wins, s.fails, `${Number(s.win_rate || 0)}%`,
      +s.wins ? Number(s.average_guesses).toFixed(2) : "-",
      s.current_streak, s.best_streak,
    ];
    [...$("dexleMetrics").children].forEach((el, i) =>
      el.querySelector("b").textContent = values[i]);

    const dist = s.guess_distribution || {};
    const max = Math.max(1, ...Array.from({length:10}, (_,i) => +(dist[i+1] || 0)));
    $("guessChart").innerHTML = Array.from({length:10}, (_,i) => {
      const guess = i + 1;
      const count = +(dist[guess] || 0);
      const width = count ? Math.max(3, count / max * 100) : 0;
      return `<div class="guess-row">
        <span class="guess-label">${guess} guess${guess === 1 ? "" : "es"}</span>
        <div class="guess-track" title="${count} win${count === 1 ? "" : "s"}">
          <div class="guess-fill" style="width:${width}%"></div>
        </div>
        <span class="guess-count">${count}</span>
      </div>`;
    }).join("");
  }

  function showError(err) {
    $("error").hidden = false;
    $("error").textContent = `Stats could not load: ${err.message || err}`;
  }

  async function init() {
    if(UNLIMITED_VIEW){
      document.body.classList.add("unlimited-stats-view");
      document.querySelector("h1").textContent="Unlimited Stats";
      document.querySelector("header")?.insertAdjacentHTML("afterbegin",'<a class="unlimited-stats-back" href="unlimited.html" aria-label="Back to Unlimited modes" title="Back to Unlimited modes"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></a>');
      $("usageMode").innerHTML='<option value="">All Unlimited modes</option><option value="unlimited_region">Region Ascendant</option><option value="unlimited_gauntlet">Infinite Gauntlet</option><option value="base_max">Base Form Fury</option>';
      $("historyTabs").innerHTML='<button class="on" data-mode="unlimited_region">Region</button><button data-mode="unlimited_gauntlet">Gauntlet</button><button data-mode="base_max">Base Fury</button>';
      const personalTitles=$("personalPanel").querySelectorAll(".best-title-row h3");["Best Region Ascendant team","Best Infinite Gauntlet team","Best Base Form Fury team"].forEach((t,i)=>{if(personalTitles[i])personalTitles[i].textContent=t;});
      const communityTitles=$("communityPanel").querySelectorAll(".best-title-row h3");["Best Region Ascendant team","Best Infinite Gauntlet team","Best Base Form Fury team"].forEach((t,i)=>{if(communityTitles[i])communityTitles[i].textContent=t;});
      ["bestRegion","communityBestRegion"].forEach(id=>$(id)?.closest("label")?.setAttribute("hidden",""));
    }
    $("summary").after($("personalPanel"), $("usagePanel"), $("communityPanel"), $("historyPanel"));
    const historyToggle = document.createElement("button");
    historyToggle.className = "history-toggle";
    historyToggle.type = "button";
    historyToggle.setAttribute("aria-expanded", "false");
    historyToggle.innerHTML = '<span>View teams</span><i aria-hidden="true">&#9662;</i>';
    $("historyPanel").querySelector(".section-head").appendChild(historyToggle);
    const historyParts = [$("historyTabs"), $("historyFilters"), $("history")];
    historyParts.forEach(part => part.hidden = true);
    historyToggle.onclick = () => {
      const open = historyToggle.getAttribute("aria-expanded") !== "true";
      historyToggle.setAttribute("aria-expanded", String(open));
      historyToggle.querySelector("span").textContent = open ? "Close teams" : "View teams";
      historyParts.forEach(part => part.hidden = !open);
    };
    ["historyRegion","bestRegion","communityBestRegion"]
      .forEach(id => $(id).innerHTML = regionOptions("All regions"));
    $("usageGeneration").innerHTML = '<option value="">All generations</option>' +
      Array.from({length:9},(_,i) => `<option value="${i+1}">Generation ${i+1}</option>`).join("");
    if (!DexleStats.configured) {
      $("setup").hidden = false;
      drawSummary({runs:0});
      drawLeaders([]);
      drawHistory();
      drawBests();
      $("communityBestRegionCard").innerHTML = communityBestCard(null);
      $("communityBestGauntletCard").innerHTML = communityBestCard(null);
      $("communityBestRocketCard").innerHTML = communityBestCard(null);
      return;
    }
    try {
      const [mine, community] = await Promise.all([
        DexleStats.personalRuns(),
        DexleStats.communitySummary(),
      ]);
      runs = UNLIMITED_VIEW ? mine.filter(r=>["unlimited_region","unlimited_gauntlet","base_max"].includes(r.mode)) : mine;
      drawSummary(community);
      await refreshCommunityBests();
      await refreshLeaderboard();
      drawHistory();
      drawBests();
    } catch (err) { showError(err); }
  }

  $("scopeTabs").onclick = e => {
    const b = e.target.closest("[data-scope]"); if (!b) return;
    scope = b.dataset.scope;
    [...$("scopeTabs").children].forEach(x => x.classList.toggle("on",x===b));
    refreshLeaderboard();
  };
  $("historyTabs").onclick = e => {
    const b = e.target.closest("[data-mode]"); if (!b) return;
    historyMode = b.dataset.mode;
    [...$("historyTabs").children].forEach(x => x.classList.toggle("on",x===b));
    drawHistory();
  };
  $("usageMode").onchange = refreshLeaderboard;
  $("usageGeneration").onchange = refreshLeaderboard;
  $("usageStarterTabs").onclick = e => {
    const b = e.target.closest("[data-starters]"); if (!b) return;
    showStarters = b.dataset.starters === "true";
    [...$("usageStarterTabs").children].forEach(x => x.classList.toggle("on", x === b));
    refreshLeaderboard();
  };
  $("historyRegion").onchange = drawHistory;
  $("bestRegion").onchange = drawBests;
  $("communityBestRegion").onchange = refreshCommunityBests;
  init();
})();
